package SuperWeb_Meta;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_utils {

	public static String inputexcle;

	static Excel_Reader reader;

	public static ArrayList<Object[]> getDataFromexcel() {

		ArrayList<Object[]> myData = new ArrayList<Object[]>();
		try {

			inputexcle = "D:\\eclipse-workspace\\GTM_TEST\\SuperWeb_MetaTest\\SuperWeb_Report.xlsx";

			System.out.println(inputexcle);

			reader = new Excel_Reader(inputexcle);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int rowNum = 2; rowNum <= reader.getRowCount("Sheet1"); rowNum++) {
			String INDEX = reader.getCellData("Sheet1", "INDEX", rowNum);
			String PageURL = reader.getCellData("Sheet1", "PageURL", rowNum);

			String Title = reader.getCellData("Sheet1", "Title", rowNum).toLowerCase().trim();
			if (Title.length() == 0) {
				Title = "No excel data found";
			}

			String Title_result = reader.getCellData("Sheet1", "Title_result", rowNum);
			String Website_title = reader.getCellData("Sheet1", "Website_title", rowNum);

			String Description = reader.getCellData("Sheet1", "Description", rowNum).toLowerCase().trim();
			if (Description.length() == 0) {
				Description = "No excel data found";
			}

			String Description_result = reader.getCellData("Sheet1", "Description_result", rowNum).toLowerCase().trim();
			String Website_description = reader.getCellData("Sheet1", "Website_description", rowNum).toLowerCase()
					.trim();

			String keywords = reader.getCellData("Sheet1", "keywords", rowNum).toLowerCase().trim();
			String keywords_result = reader.getCellData("Sheet1", "keywords_result", rowNum).toLowerCase().trim();
			String Website_keywords = reader.getCellData("Sheet1", "Website_keywords", rowNum).toLowerCase().trim();

			if (keywords.length() == 0) {
				keywords = "No excel data found";
			}
//			String H1Tags = reader.getCellData("Sheet1", "H1Tags", rowNum).toLowerCase().trim();
//
//			if (H1Tags.length() == 0) {
//				H1Tags = "No excel data found";
//			}

			Object ob[] = { INDEX, PageURL, Title, Title_result, Website_title, Description, Description_result,
					Website_description, keywords, keywords_result, Website_keywords };

			myData.add(ob);

		}
		return myData;

	}

//Title Status 
	public static void title_Status(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(3);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

//Website_title 
	public static void Website_title(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(4);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// Description_result
	public static void Description_result(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(6);
		if (value == "FAIL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// web Description
	public static void web_description(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(7);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// Keyword_result
	public static void Keyword_result(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(9);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// Web_Keyword
	public static void Web_Keyword(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(10);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	public static void Response_code(int respCode, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(11);
		// int responsecode = Integer.parseInt(respCode);
		if (respCode > 200) {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(respCode);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(respCode);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// Canonical
	public static void Canonical_Url(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(1);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// Index_Status
	public static void Index_Status(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(2);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// GTM_Status
	public static void GTM_Status(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(3);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// Schema_Status
	public static void Schema_Status(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(4);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// h1-count
	public static void h1_count_write(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(5);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// h2-count
	public static void h2_count_write(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(6);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}

	// h3-count
	public static void h3_count_write(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(7);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}

	// h4-count
	public static void h4_count_write(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(8);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}

	// h5-count
	public static void h5_count_write(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(9);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}

	// h6-count
	public static void h6_count_write(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(10);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}
	
	public static void og_tag_write(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(11);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// time
	public static void time_write(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(1);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(12);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}



	public static void writeinexcel7(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);

		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);

		XSSFCell c = row.createCell(11);
		if (value.length() > 0) {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	public static void writeinexcel9(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(12);
		int H1parseInt = Integer.parseInt(value);
		if (H1parseInt > 1) {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	public static void writeinexcel8(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(13);

		if (value == "PASS") {
			c.setCellValue(value);

		} else {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	public static void writeinexcel10(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(14);
		if (value == "FAIL" || value == "INVALID URL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	public static void writeinexcel11(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(15);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// time stamp
	public static void writeinexcel13(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(17);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	public static void writeinexcel14(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(19);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	public static void writeinexcel15(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(18);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	public static void writeinexcel16(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(20);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}

	public static void writeinexcel17(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(21);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}

	public static void writeinexcel18(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(22);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}

	public static void writeinexcel19(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(23);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}

	public static void writeinexcel20(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(24);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}

	public static void writeinexcel21(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(25);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();

	}

}
