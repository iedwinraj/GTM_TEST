package SuperWeb_Meta;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.SkipException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class SuperWeb_Test extends LibGlobal {
	int count = 0;
	static int respCode = 200;
	static HttpURLConnection huc = null;
	LibGlobal lb = new LibGlobal();
	static List<String> Schemadata = new ArrayList<String>();

	static List<String> Gtmdata = new ArrayList<String>();

	@DataProvider
	public Iterator<Object[]> getTestData() {
		
		ArrayList<Object[]> testData = Excel_utils.getDataFromexcel();
		return testData.iterator();
	}

	@Parameters("browser")
	@BeforeTest
	private void browserExe() throws InterruptedException {

		launchBrowser("chrome");

	}

	@Test(dataProvider = "getTestData")
	public void shouldAnswerWithTrue(String INDEX, String PageURL, String Title, String Title_result,
			String Website_title, String Description, String Description_result, String Website_description,
			String keywords, String keywords_result, String Website_keywords) throws Exception {

		System.out.println("Welcome");

		loadUrl(PageURL);

		int parseInt = Integer.parseInt(INDEX);

//TITLE
		try {

			String Actualtitle = driver.getTitle().toLowerCase().trim();

			System.out.println(Actualtitle + "\t" + "--PAGE TITLE ");

			System.out.println(Title + "\t" + "--Excel Data");

			if ((Actualtitle.equals(Title.toLowerCase().trim()))) {

				Excel_utils.title_Status("PASS", parseInt);
				System.out.println("PASS");
			} else {
				Excel_utils.title_Status("FAIL", parseInt);

				Excel_utils.Website_title(Actualtitle, parseInt);
				// System.out.println("FAIL");

			}

		} catch (Exception e) {
			System.out.println("Title_Exception");
		}

//Description

		try {

			Thread.sleep(1000);
			String pageDescription = lb.getPageDescription().toLowerCase().trim();
			System.out.println(pageDescription + "\t" + "--PAGE DESCRIPTION");
			System.out.println(Description + "\t" + "--Excel Data");

			if (Description.toLowerCase().trim().equals(pageDescription)) {
				Excel_utils.Description_result("PASS", parseInt);
				System.out.println("PASS");

			} else {

				Excel_utils.Description_result("FAIL", parseInt);
				Excel_utils.web_description(pageDescription, parseInt);
				System.out.println("FAIL");
			}

//Thread.sleep(1000);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

//Keyword Test

		try {
			String pageKeywords = lb.getPageKeywords().toLowerCase().trim();

			System.out.println(pageKeywords + "\t" + "--PAGE KEYWORDS");
			System.out.println(keywords + "\t" + "--Excel Data");

			if (keywords.toLowerCase().trim().equals(pageKeywords)) {
				Excel_utils.Keyword_result("PASS", parseInt);
				System.out.println("PASS");
			} else {

				Excel_utils.Keyword_result("FAIL", parseInt);
				Excel_utils.Web_Keyword(pageKeywords, parseInt);
				System.out.println("FAIL");

			}
		} catch (Exception e) {
			System.out.println("Keyword_Exception");
		}

//Response Code		

		try {

			huc = (HttpURLConnection) (new URL(PageURL).openConnection());

			huc.setRequestMethod("GET");

			huc.connect();

			respCode = huc.getResponseCode();

			if (respCode != 200) {

				System.out.println(PageURL + " is a broken link" + " ==> " + respCode);

				Excel_utils.title_Status("INVALID URL", parseInt);
				// Excel_utils.writeinexcel3("INVALID URL", parseInt);
				// Excel_utils.writeinexcel4("INVALID URL", parseInt);
				// Excel_utils.writeinexcel5("INVALID URL", parseInt);
				// Excel_utils.writeinexcel6("INVALID URL", parseInt);
				Excel_utils.writeinexcel7("INVALID URL", parseInt);
				Excel_utils.Response_code(respCode, parseInt);

				++count;
				throw new SkipException("skip");

			} else {

				System.out.println(PageURL + " is a Valid link" + " ==> " + respCode);
				Excel_utils.Response_code(respCode, parseInt);

			}

		} catch (Exception e) {
			System.out.println("StatusException");

		}

//Get Canonical

		try {
			String tagcanonical = driver.findElement(By.xpath("//link[@rel='canonical']")).getAttribute("href");

			if (tagcanonical.length() > 0) {
				System.out.println(tagcanonical + " ==>" + "Canonical Ok");
				Excel_utils.Canonical_Url(tagcanonical, parseInt);

			} else {
				System.out.println("Canonical Fail");
				Excel_utils.Canonical_Url("C", parseInt);
			}

		} catch (Exception e1) {
			Excel_utils.Canonical_Url("FAIL", parseInt);

		}

		// Index Follow

		try {
			Thread.sleep(2000);

			boolean displayed = driver.findElements(By.xpath("//meta[contains(@content,'index, follow')]")).size() > 0;

			if (displayed) {

				System.out.println(PageURL + "==>" + "Index follow");
				Excel_utils.Index_Status("Index Follow", parseInt);
			} else {
				System.out.println(PageURL + "==>" + "Noindex nofollow ");
				Excel_utils.Index_Status("Noindex Nofollow ", parseInt);

			}
		} catch (Exception e) {
			System.out.println("IndexException");
		}

		// GTM Verification

		try {
			Thread.sleep(1000);

			List<WebElement> gtmid_list = driver.findElements(By.xpath("//script[contains(text(),'GTM-')]"));

			for (WebElement webElement : gtmid_list) {
				String gtmname = webElement.getAttribute("text");

				// Pattern pattern = Pattern.compile("GTM-([^\"]+)");
				Pattern pattern = Pattern.compile("id=GTM-([^\"]+)");

				Matcher matcher = pattern.matcher(gtmname);

				if (matcher.find()) {
					String gtmId = matcher.group(1);
					// Print or use the GTM ID as needed

					Gtmdata.add(gtmId);
				}

			}

			String join2 = String.join(", " + "\n", Gtmdata);
			// String join2 = String.join(", ", Gtmdata);
			parseInt = Integer.parseInt(INDEX);
			System.out.println("GTM ID: " + Gtmdata);
			Excel_utils.GTM_Status(join2, parseInt);
			Gtmdata.clear();

		} catch (Exception e) {
			System.out.println("GTM exception");
		}

		// Schema

		try {
			// Find all elements with the specified ID

			List<WebElement> scriptElements = driver.findElements(By.xpath("//script[@type='application/ld+json']"));

			for (WebElement scriptElement : scriptElements) {
				// Get the content of each script
				String scriptContent = scriptElement.getAttribute("innerHTML");

				if (scriptContent.length() > 0) {

					JSONObject json = new JSONObject(scriptContent);

					// System.out.println(json.toString());

					String schemacontent = json.getString("@type");

					Schemadata.add(schemacontent);
					// String join = String.join(", "+"\n", Schemadata );
				}

			}
			String join = String.join(", " + "\n", Schemadata);
			parseInt = Integer.parseInt(INDEX);
			Excel_utils.Schema_Status(join, parseInt);
			System.out.println("Schema" + " ==>" + Schemadata);
			// Excel_utils.writeinexcel15("Schema Verifed", parseInt);
			Schemadata.clear();

		} catch (Exception e) {
			e.printStackTrace();
			Excel_utils.Schema_Status("Fail", parseInt);
			// Excel_utils.writeinexcel15("Fail", parseInt);
		}

// H1s are a good indicator of what the most important text on a page is
// H1 Tag count

		try {
			List<WebElement> findElements = driver.findElements(By.tagName("h1"));

			Thread.sleep(1000);
			String h1count = String.valueOf(findElements.size());
			System.out.println("h1 count is:" + "" + findElements.size());
			if (h1count.isEmpty()) {

				System.out.println("h1 count is:" + "" + " No h1 ");
				Excel_utils.h1_count_write("No h1", parseInt);

			} else if (h1count.length() >= 1) {

				for (WebElement webElement : findElements) {
					String text = webElement.getText();
					System.out.println("h1 Header" + " ==> " + text);

					System.out.println("H1 Pass");
					Excel_utils.h1_count_write(h1count, parseInt);
					Excel_utils.writeinexcel8("FAIL", parseInt);
				}

			} else {
				System.out.println("H1 Fail");
				Excel_utils.h1_count_write(h1count, parseInt);

			}

		} catch (Exception e) {
			System.out.println("h1 Failed");
		}

// H2 tag

		try {
			List<WebElement> findElements = driver.findElements(By.tagName("h2"));

			Thread.sleep(1000);
			String h2count = String.valueOf(findElements.size());
			System.out.println("h2 count is:" + "" + findElements.size());
			if (h2count.isEmpty()) {

				System.out.println("h2 count is:" + "" + " No h1 ");
				Excel_utils.h1_count_write("No h2", parseInt);

			} else if (h2count.length() >= 1) {

				for (WebElement webElement : findElements) {
					String text = webElement.getText();
					System.out.println("h2 Header" + " ==> " + text);

					System.out.println("H2 Pass");
					Excel_utils.h1_count_write(h2count, parseInt);
					Excel_utils.writeinexcel8("FAIL", parseInt);
				}

			} else {
				System.out.println("H2 Fail");
				Excel_utils.h1_count_write(h2count, parseInt);

			}

		} catch (Exception e) {
			System.out.println("h1 Failed");
		}

// H3 Tag

		try {
			List<WebElement> h3tags = driver.findElements(By.tagName("h3"));
			System.out.println("h3 count is:" + "" + h3tags.size());
			String h3count = String.valueOf(h3tags.size());
			Excel_utils.h3_count_write(h3count, parseInt);
			Thread.sleep(1000);
		} catch (Exception e) {
			System.out.println("h3 Failed");
		}

// H4 Tag
		try {
			List<WebElement> h4tags = driver.findElements(By.tagName("h4"));
			System.out.println("h4 count is:" + "" + h4tags.size());
			String h4count = String.valueOf(h4tags.size());
			Excel_utils.h4_count_write(h4count, parseInt);
			Thread.sleep(1000);
		} catch (Exception e) {
			System.out.println("h4 Failed");
		}

//H5 Tag

		try {

			List<WebElement> h5tags = driver.findElements(By.tagName("h5"));
			System.out.println("h5 count is:" + "" + h5tags.size());
			String h5count = String.valueOf(h5tags.size());
			Excel_utils.h5_count_write(h5count, parseInt);
			Thread.sleep(1000);

		} catch (Exception e) {
			System.out.println("h5 Failed");
		}

//H6 Tag
		try {

			List<WebElement> h6tags = driver.findElements(By.tagName("h6"));
			System.out.println("h6 count is:" + "" + h6tags.size());
			String h6count = String.valueOf(h6tags.size());
			Excel_utils.h6_count_write(h6count, parseInt);
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("h5 Failed");
		}

		// OG Tag

		try {
			// driver.findElement(By.xpath("//meta[contains(@content,'noindex,nofollow,')]"));
			List<String> ogdata = new ArrayList<String>();
			List<WebElement> sitemapurls = driver.findElements(By.xpath("//meta[contains(@property,'og:')]"));
			int i = 1;
			for (WebElement webElement : sitemapurls) {

				String ogtagresult = webElement.getAttribute("content");
				String ogt1agresult = webElement.getAttribute("property");

				// System.out.println(ogt1agresult + ":" + ogtagresult);

				System.out.println(i + " " + ogt1agresult + ":" + ogtagresult);
				ogdata.add(i + " " + ogt1agresult + ":" + ogtagresult);

				if (!webElement.getText().isBlank()) {
					// objwriteExcel.write_to_Excel(path, filename, SheetRobotsContent,
					// webElement.getText());

					Excel_utils.og_tag_write(ogtagresult, parseInt);

				}
				i++;
			}
			// System.out.println(sitemapurls.size());
			String join = String.join(", " + "\n", ogdata);

			Excel_utils.og_tag_write(join, parseInt);
			System.out.println("<------------------------------------------>");
		} catch (Exception e1) {

			System.out.println("OG Exception");
		}

		Thread.sleep(1000);

		SimpleDateFormat dateformet = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date = new Date();
		String format = dateformet.format(date);
		Excel_utils.time_write(format, parseInt);

		System.out.println(++count + "\t" + "is Row is completed." + "\t" + format);

	}

	@AfterTest
	public void driver_close() throws InterruptedException {

//Thread.sleep(2000);
		driver.quit();

	}

}
