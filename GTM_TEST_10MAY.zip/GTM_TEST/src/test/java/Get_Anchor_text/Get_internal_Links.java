package Get_Anchor_text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Get_internal_Links extends LibGlobal {

	@BeforeClass
	public void browserLaunch() {

		launchBrowser("edge");
	}

	static List<String> data = new ArrayList<String>();

	@DataProvider
	public Iterator<Object[]> getTestData() {

		ArrayList<Object[]> testData = Excel_utils.getDataFromexcel();
		return testData.iterator();

	}

	@Test(dataProvider = "getTestData")
	public void execute(String INDEX, String Articles_URL, String anchor) {

		try {

			System.out.println(INDEX + ") ==> " + Articles_URL);

			loadUrl(Articles_URL);

			
			try {
				Thread.sleep(2000);
				// WebDriverWait Webwait = new WebDriverWait(driver, Duration.ofSeconds(45));

				// List<WebElement> allLinks = driver.findElements(By.tagName("a"));

				List<WebElement> allLinks = driver.findElements(By.tagName("a"));

				Thread.sleep(1000);

				for (WebElement link : allLinks) {

					String text = link.getText();

					String attribute = link.getAttribute("href");

				//	if (text.trim().equals(anchor.trim())) {
						//System.out.println(text + " == " + anchor);
						data.add(attribute);

						// System.out.println(attribute);

				//	}

				}

				String join = String.join(", " + "\n", data);

				if (join.length() > 0) {
					System.out.println(join);
					int parseInt = Integer.parseInt(INDEX);
					Excel_utils.writeinexcel2(join, parseInt);
					data.clear();
				} else {
					System.out.println("No other Domain");
					int parseInt = Integer.parseInt(INDEX);
					Excel_utils.writeinexcel2("No other Domain", parseInt);
					data.clear();
				}

				SimpleDateFormat dateformet = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				Date date = new Date();
				String format = dateformet.format(date);
				int parseInt = Integer.parseInt(INDEX);
				Excel_utils.writeinexcel3(format, parseInt);

			} catch (StaleElementReferenceException e) {

				// WebDriverWait Webwait = new WebDriverWait(driver, Duration.ofSeconds(45));

				// List<WebElement> allLinks = driver.findElements(By.tagName("a"));

				List<WebElement> allLinks = driver.findElements(By.tagName("a"));

				Thread.sleep(1000);

				for (WebElement link : allLinks) {

					String text = link.getText();

					String attribute = link.getAttribute("href");

					//if (text.trim().equals(anchor.trim())) {
						//System.out.println(text + " == " + anchor);
						data.add(attribute);

						// System.out.println(attribute);

				//	}

				}

				String join = String.join(", " + "\n", data);

				if (join.length() > 0) {
					System.out.println(join);
					int parseInt = Integer.parseInt(INDEX);
					Excel_utils.writeinexcel2(join, parseInt);
					data.clear();
				} else {
					System.out.println("No other Domain");
					int parseInt = Integer.parseInt(INDEX);
					Excel_utils.writeinexcel2("No other Domain", parseInt);
					data.clear();
				}

				SimpleDateFormat dateformet = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				Date date = new Date();
				String format = dateformet.format(date);
				int parseInt = Integer.parseInt(INDEX);
				Excel_utils.writeinexcel3(format, parseInt);

			}

		} catch (Exception e) {

			e.printStackTrace();

		}

		// driver.quit();

	}

	@AfterTest
	public void browserQuit() {

		driver.quit();

	}

}
