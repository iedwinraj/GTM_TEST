package OG_TAG;

import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class og_Test extends LibGlobal {
	int count = 0;
	static int respCode = 200;
	static HttpURLConnection huc = null;
	LibGlobal lb = new LibGlobal();
	static List<String> Schemadata = new ArrayList<String>();

	static List<String> Gtmdata = new ArrayList<String>();

	@DataProvider
	public Iterator<Object[]> getTestData() {
		
		ArrayList<Object[]> testData = Excel_utils.getDataFromexcel();
		return testData.iterator();
	}

	@Parameters("browser")
	@BeforeTest
	private void browserExe() throws InterruptedException {

		launchBrowser("chrome");

	}

	@Test(dataProvider = "getTestData")
	public void shouldAnswerWithTrue(String INDEX, String PageURL) throws Exception {

		System.out.println("Welcome");

		loadUrl(PageURL);
		System.out.println(PageURL);

				// OG Tag

		try {
			Thread.sleep(1000);
			// driver.findElement(By.xpath("//meta[contains(@content,'noindex,nofollow,')]"));
			List<String> ogdata = new ArrayList<String>();
			//List<WebElement> sitemapurls = driver.findElements(By.xpath("//meta[contains(@property,'og:')]"));
			
			List<WebElement> sitemapurls = driver.findElements(By.xpath("//meta[contains(@property,'og:image')]"));
			
			int i = 1;
			for (WebElement webElement : sitemapurls) {

				String ogtagresult = webElement.getAttribute("content");
				String ogt1agresult = webElement.getAttribute("property");

				// System.out.println(ogt1agresult + ":" + ogtagresult);

				System.out.println(i + " " + ogt1agresult + ":" + ogtagresult);
				ogdata.add(i + " " + ogt1agresult + ":" + ogtagresult);

				if (!webElement.getText().isBlank()) {
					// objwriteExcel.write_to_Excel(path, filename, SheetRobotsContent,
					// webElement.getText());
					int parseInt = Integer.parseInt(INDEX);
					Excel_utils.og_tag_write(ogtagresult, parseInt);

				}
				i++;
			}
			// System.out.println(sitemapurls.size());
			String join = String.join(", " + "\n", ogdata);
			int parseInt = Integer.parseInt(INDEX);
			Excel_utils.og_tag_write(join, parseInt);
			System.out.println("<------------------------------------------>");
		} catch (Exception e1) {

			System.out.println("OG Exception");
		}

		Thread.sleep(1000);

		SimpleDateFormat dateformet = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date = new Date();
		String format = dateformet.format(date);
		int parseInt = Integer.parseInt(INDEX);
		Excel_utils.time_write(format, parseInt);

		System.out.println(++count + "\t" + "is Row is completed." + "\t" + format);

	}

	@AfterTest
	public void driver_close() throws InterruptedException {

//Thread.sleep(2000);
		driver.quit();

	}

}
