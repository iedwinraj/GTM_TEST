package DataLayer;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import ResponseCode.LibGlobal;

public class getDatalayer extends LibGlobal {

	@Parameters("browser")
	@BeforeTest
	public void browserExe() {

		launchBrowser("edge");

	}

	@Test
	public void dataLayer_info() throws Exception {

		loadUrl("https://www.shriramfinance.in/fixed-deposit");

		Thread.sleep(5000);
		try {// Corrected script

			String script = "return window.dataLayer;"; // Get the entire dataLayer

			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			Object result = jsExecutor.executeScript(script); // Execute the JavaScript

			// If the result is a list, process it to extract the information
			if (result instanceof List) {
				List<?> dataLayer = (List<?>) result; // Cast the result to a list

				// Loop through the dataLayer and log information
				for (Object item : dataLayer) {
					System.out.println(item); // Output the data
				}
			} else {
				System.out.println("No dataLayer found.");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());

		}

	}

	@Test
	public void dataLayer_info1() throws Exception {

		loadUrl("https://www.shriramfinance.in/fixed-investment-plan");

		Thread.sleep(5000);
		try {// Corrected script

			// JavaScript to filter the dataLayer for event='customDL'
			String script = "return window.dataLayer.filter(item => item.event === 'customDL');";

			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			Object result = jsExecutor.executeScript(script); // Execute the script

			// If the result is a list, process it
			if (result instanceof List) {
				List<?> customDLEvents = (List<?>) result;

				// If there is at least one customDL event
				if (!customDLEvents.isEmpty()) {
					// Get the first matching event
					@SuppressWarnings("unchecked")
					Map<String, Object> customDLEvent = (Map<String, Object>) customDLEvents.get(0); // Cast to a map

					// Get the page details from the customDL event
					@SuppressWarnings("unchecked")
					Map<String, Object> pageDetails = (Map<String, Object>) customDLEvent.get("page");

					System.out.println("CustomDL event details: " + customDLEvent);
					System.out.println("Page details: " + pageDetails);
				} else {
					System.out.println("No 'customDL' event found.");
				}
			} else {
				System.out.println("Unexpected data type returned.");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());

		}

	}

	@AfterTest
	public void close() throws InterruptedException {

		// Thread.sleep(2000);
		driver.quit();

	}

}
