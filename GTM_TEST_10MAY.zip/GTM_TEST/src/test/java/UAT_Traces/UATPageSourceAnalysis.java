package UAT_Traces;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import googleTagManagerTest.emailSend;
import io.github.bonigarcia.wdm.WebDriverManager;


@Test
public class UATPageSourceAnalysis  {
	
	
	public void main() {
		
			WebDriverManager.chromedriver().setup();

	        // Set the path to chromedriver executable
	        //System.setProperty("webdriver.chrome.driver", "D:\\eclipse-workspace-new\\GTM_TEST\\MyDrivers\\chromedriver.exe");

	        // Initialize ChromeDriver
	        WebDriver driver = new ChromeDriver();

	        // Navigate to the webpage
	        driver.get("https://uat1.shriramfinance.in");

	        // Get page source
	        String pageSource = driver.getPageSource();

	        // Analyze page source to find UAT traces
	        if (pageSource.contains("uatcdn")) {
	            System.out.println("UAT trace found in this page");
	            emailSend.localemailSend();
	            
	        } else {
	            System.out.println("No UAT traces");
	        }

	        // Close the browser
	        driver.quit();
	    
	}
}
