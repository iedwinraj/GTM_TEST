package googleTagManagerTest;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class FindExternalLinks extends LibGlobal {

	static List<String> data = new ArrayList<String>();
	@BeforeClass
	public void browserLaunch() {

		launchBrowser("edge");
	}

	@DataProvider
	public Iterator<Object[]> getTestData() {

		ArrayList<Object[]> testData = Excel_utils.getDataFromexcel();
		return testData.iterator();

	}

	@Test(dataProvider = "getTestData")
	public static void main(String INDEX, String Articles_URL) throws Exception {

		try {
			// Navigate to a webpage
			loadUrl(Articles_URL);
			System.out.println(Articles_URL);

			// Get the base domain of the current page
			String baseDomain = getDomainName(driver.getCurrentUrl());

			// Find all the links on the page
			List<WebElement> links = driver.findElements(By.tagName("a"));

			System.out.println("External links found:");

			// Loop through each link
			for (WebElement link : links) {
				String href = link.getAttribute("href");

				if (href != null) {
					// Get the domain of the link
					String linkDomain = getDomainName(href);

					// If the link's domain is different from the base domain, it's an external link
					if (!linkDomain.equals(baseDomain)) {
						System.out.println(href);
						data.add(href);
					}
					String join = String.join(", " + "\n", data);
					
					if (join.isEmpty()) {
						System.out.println("No other Domain Link");
						int parseInt = Integer.parseInt(INDEX);
						Excel_utils.writeinexcel2("No other Domain Link", parseInt);
						data.clear();

					} else {
						System.out.println(join);
						int parseInt = Integer.parseInt(INDEX);
						Excel_utils.writeinexcel2(join, parseInt);
						data.clear();
					}
				}
				
			}
			
			
			
		
			
		} finally {
			// Close the browser
			//driver.quit();
		}
	}

	// Utility method to extract the domain name from a URL
	private static String getDomainName(String url) throws URISyntaxException {
		URI uri = new URI(url);
		String host = uri.getHost();

		// Remove "www." if present to ensure consistent comparisons
		if (host != null && host.startsWith("www.")) {
			host = host.substring(4);
		}

		return host;
	}

	@AfterTest
	public void browserQuit() {

		driver.quit();

	}

}
