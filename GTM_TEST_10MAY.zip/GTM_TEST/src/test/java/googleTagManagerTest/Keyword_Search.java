package googleTagManagerTest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Keyword_Search extends LibGlobal {

	@BeforeClass
	public void browserLaunch() {

		launchBrowser("edge");
	}

	static List<String> data = new ArrayList<String>();

	@DataProvider
	public Iterator<Object[]> getTestData() {

		ArrayList<Object[]> testData = Excel_utils.getDataFromexcel();
		return testData.iterator();

	}

	@Test(dataProvider = "getTestData")
	public void execute(String INDEX, String Articles_URL) {

		try {

			System.out.println(INDEX + ") ==> " + Articles_URL);

			loadUrl(Articles_URL);

			try {
				Thread.sleep(2000);
				
				
				List<WebElement> returntxt = driver.findElements(By.xpath("//*[contains (text(),'8.50')]"));

				if (returntxt.size() > 0) {
					WebElement returntext = driver.findElement(By.xpath("//*[contains (text(),'8.50')]"));
					
					int parseInt = Integer.parseInt(INDEX);
					Excel_utils.writeinexcel2(returntext.getAttribute("href"), parseInt);
					System.out.println(returntext.getAttribute("href"));

				} else {
					int parseInt = Integer.parseInt(INDEX);
					Excel_utils.writeinexcel2("NO Given Keyword", parseInt);
					System.out.println("NO Given Keyword");
				}

				SimpleDateFormat dateformet = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				Date date = new Date();
				String format = dateformet.format(date);
				
				int parseInt = Integer.parseInt(INDEX);
				Excel_utils.writeinexcel3(format, parseInt);

			} catch (StaleElementReferenceException e) {

			}

		} catch (Exception e) {

			e.printStackTrace();

		}

		// driver.quit();

	}

	@AfterTest
	public void browserQuit() {

		driver.quit();

	}

}
