package googleTagManagerTest;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;



public class Get_table_info  extends LibGlobal {
	
	@BeforeClass
	public void browserLaunch() {

		launchBrowser("chrome");
	}

	static List<String> data = new ArrayList<String>();

	@DataProvider
	public Iterator<Object[]> getTestData() {

		ArrayList<Object[]> testData = Excel_utils.getDataFromexcel();
		return testData.iterator();

	}

	@Test(dataProvider = "getTestData")
	public void execute(String INDEX, String Articles_URL) {

		try {

			System.out.println(INDEX + ") ==> " + Articles_URL);

			loadUrl(Articles_URL);

			try {

				//WebDriverWait Webwait = new WebDriverWait(driver, Duration.ofSeconds(45));

				List<WebElement> allLinks = driver.findElements(By.tagName("a"));

				Thread.sleep(1000);

				for (WebElement link : allLinks) {

					String attribute = link.getAttribute("href");

					// String text = link.getAttribute("src");

					// System.out.println(attribute+" ==> "+text);

					// data.add(attribute + " ==> " + text);

//					if (attribute != null) {
//						if ((!attribute.contains("https://cdn.shriramfinance.in"))
//								&& (!attribute.contains("tel:18001034959")) && (!attribute.contains("tel:18001036369"))
//								&& (!attribute.contains("tel:02241574545"))
//								&& (!attribute.contains("tel:1800 103 4959"))
//								&& (!attribute.contains("https://secure.shriramfinance.in"))
//								&& (!attribute.contains("https://ibms.shriramfinance.me/IBMSSUITE_SFL/#/login"))
//								&& (!attribute.contains("https://www.youtube.com/@ShriramConnect"))
//								&& (!attribute.contains("https://www.facebook.com/shriramconnect"))
//								&& (!attribute.contains("https://www.instagram.com/shriramconnect/"))
//								&& (!attribute.contains("https://www.facebook.com/shriramconnect"))
//								&& (!attribute.contains("https://www.linkedin.com/company/shriramconnect"))
//								&& (!attribute.contains("mailto:customersupport@shriramfinance.in"))
//								&& (!attribute.contains("https://www.shriramfinance.in/"))
//								&& (!attribute.contains("https://sri1.page.link/tngV"))
//								&& (!attribute.contains(
//										"https://apps.apple.com/in/app/shriram-one-loans-fd-upi/id6446923754"))
//								&& (!attribute
//										.contains("https://play.google.com/store/apps/details?id=com.shriram.one, ")))
//
//						{
//
//							data.add(attribute);
//
//						}
//
//					}

					data.add(attribute);

				}

				String join = String.join(", " + "\n", data);

				if (join.length() > 0) {
					System.out.println(join);
					int parseInt = Integer.parseInt(INDEX);
					Excel_utils.writeinexcel2(join, parseInt);
					data.clear();
				} else {
					System.out.println("No other Domain");
					int parseInt = Integer.parseInt(INDEX);
					Excel_utils.writeinexcel2("No other Domain", parseInt);
					data.clear();
				}

			} catch (Exception e) {

				//System.out.println(e);

			}

		} catch (Exception e) {

			e.printStackTrace();

		}

		// driver.quit();

	}

	@AfterTest
	public void browserQuit() {

		driver.quit();

	}
	

}
