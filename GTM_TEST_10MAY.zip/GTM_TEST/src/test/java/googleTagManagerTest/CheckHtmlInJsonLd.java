package googleTagManagerTest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CheckHtmlInJsonLd extends LibGlobal {

	@BeforeClass
	public void browserLaunch() {

		launchBrowser("edge");
	}

	static List<String> data = new ArrayList<String>();

	@DataProvider
	public Iterator<Object[]> getTestData() {

		ArrayList<Object[]> testData = Excel_utils.getDataFromexcel();
		return testData.iterator();

	}

	@Test(dataProvider = "getTestData")
	public void execute(String INDEX, String Articles_URL) {

		try {

			System.out.println(INDEX + ") ==> " + Articles_URL);

			loadUrl(Articles_URL);

			// Find all `<script>` tags with type `application/ld+json`
			List<WebElement> jsonLdScripts = driver.findElements(By.xpath("//script[@type='application/ld+json']"));

			// HTML tag pattern (looks for "<" followed by word characters and ">" to detect
			// HTML tags)
			Pattern htmlPattern = Pattern.compile("<\\w+.*?>");

			boolean htmlFound = false;

			// Iterate over the found script tags
			for (WebElement script : jsonLdScripts) {
				// Get the text content of the script tag
				String scriptContent = script.getText();

				// Check if there's any HTML tag in the JSON-LD content
				if (htmlPattern.matcher(scriptContent).find()) {
					htmlFound = true;
					int parseInt = Integer.parseInt(INDEX);
					Excel_utils.writeinexcel2("HTML tag found in application.", parseInt);
					System.out.println("HTML tag found in application." + scriptContent);
					break;
				}
			}

			if (!htmlFound) {
				int parseInt = Integer.parseInt(INDEX);
				Excel_utils.writeinexcel2("No HTML tags found in application/ld+json content.", parseInt);
				System.out.println("No HTML tags.");
			}

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

	@AfterTest
	public void browserQuit() {

		driver.quit();

	}

}
