package googleTagManagerTest;

import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


/**
 * Unit test for simple App.
 */
public class Get_gtm extends LibGlobal {
	int count = 0;
	static int respCode = 200;
	static HttpURLConnection huc = null;
	LibGlobal lb = new LibGlobal();
	static List<String> Schemadata = new ArrayList<String>();

	static List<String> Gtmdata = new ArrayList<String>();

	@DataProvider
	public Iterator<Object[]> getTestData() {
		ArrayList<Object[]> testData = Excel_utils.getDataFromexcel();
		return testData.iterator();
	}

	@Parameters("browser")
	@BeforeTest
	private void browserExe() {

		launchBrowser("chrome");

	}

	@Test(dataProvider = "getTestData")
	public void shouldAnswerWithTrue(String INDEX, String PageURL) throws Exception {

		loadUrl(PageURL);

		System.out.println(PageURL);

		int parseInt = Integer.parseInt(INDEX);

		// GTM Verification

		try {
			Thread.sleep(1000);

			List<WebElement> gtmid_list = driver.findElements(By.xpath("//script[contains(text(),'GTM-')]"));

			for (WebElement webElement : gtmid_list) {
				String gtmname = webElement.getAttribute("text");

				//Pattern pattern = Pattern.compile("GTM-([^\"]+)");
				Pattern pattern = Pattern.compile("id=GTM-([^\"]+)");
				//Pattern pattern = Pattern.compile("^\".*\"$");
				
				Matcher matcher = pattern.matcher(gtmname);

				if (matcher.find()) {
					String gtmId = matcher.group(1);
					// Print or use the GTM ID as needed
					System.out.println("GTM ID: " + gtmId);

					Gtmdata.add(gtmId);
				}

			}

			String join2 = String.join(", " + "\n", Gtmdata);
			parseInt = Integer.parseInt(INDEX);
			System.out.println(join2);
			Excel_utils.writeinexcel2(join2, parseInt);
			Gtmdata.clear();

		} catch (Exception e) {
			System.out.println("GTM exception");
		}

		SimpleDateFormat dateformet = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date = new Date();
		String format = dateformet.format(date);

		System.out.println(++count + "\t" + "is Row is completed." + "\t" + format);

	}

	@AfterTest
	public void driver_close() throws InterruptedException {

		// Thread.sleep(2000);
		driver.quit();

	}

}
