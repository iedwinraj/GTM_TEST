package googleTagManagerTest;

import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Get_Title_Description_Keyword extends LibGlobal{

	int count = 0;
	static int respCode = 200;
	static HttpURLConnection huc = null;
	LibGlobal lb = new LibGlobal();
	static List<String> Schemadata = new ArrayList<String>();

	static List<String> Gtmdata = new ArrayList<String>();

	@DataProvider
	public Iterator<Object[]> getTestData() {
		ArrayList<Object[]> testData = Excel_utils.getDataFromexcel();
		return testData.iterator();
	}

	@Parameters("browser")
	@BeforeTest
	private void browserExe() {

		launchBrowser("chrome");

	}

	@Test(dataProvider = "getTestData")
	public void shouldAnswerWithTrue(String INDEX, String PageURL, String Title, String Description, String keywords,
			String H1Tags) throws Exception {

		System.out.println("Welcome");
		String metatest = driver.getPageSource().toLowerCase().trim();
		// 0-4 second load time is best for conversion rates,
		// and the first five seconds of page-load time have the highest impact on
		// conversion rates

		loadUrl(PageURL);

		int parseInt = Integer.parseInt(INDEX);

//Title 

		try {

			String Actualtitle = driver.getTitle().toLowerCase().trim();

			System.out.println(Actualtitle + "\t" + " --PAGE TITLE ");

			System.out.println(Title + "\t" + "--Excel Data");

			if ((Actualtitle.equals(Actualtitle.toLowerCase().trim()))) {

				Excel_utils.writeinexcel2("PASS", parseInt);
				System.out.println("PASS");
			} else {
				// int parseInt = Integer.parseInt(INDEX);
			//	Excel_utils.writeinexcel2("FAIL", parseInt);

				//Excel_utils.writeinexcel5(Actualtitle, parseInt);
				System.out.println("FAIL");

			}

		} catch (Exception e) {
			System.out.println("TitleException");
		}

//Description

		try {

			Thread.sleep(1000);

			String pageDescription = lb.getPageDescription().toLowerCase().trim();

			// boolean desctest =
			// driver.getPageSource().contains(Description.trim().toLowerCase());

			System.out.println(pageDescription + "\t" + " --PAGE DESCRIPTION");
			System.out.println(Description + "\t" + "--Excel Data");

			if (Description.toLowerCase().trim().equals(pageDescription)) {

			//	Excel_utils.writeinexcel3("PASS", parseInt);
				System.out.println("PASS");

			} else {
				// int parseInt = Integer.parseInt(INDEX);
			//	Excel_utils.writeinexcel3("FAIL", parseInt);
			//	Excel_utils.writeinexcel6(pageDescription, parseInt);
				System.out.println("FAIL");
			}

			Thread.sleep(1000);

		} catch (Exception e) {
			// TODO: handle exception
		}

//Keywords
		
		try {
			String pageKeywords = lb.getPageKeywords().toLowerCase().trim();

			System.out.println(pageKeywords + "\t" + " --PAGE KEYWORDS");
			System.out.println(keywords + "\t" + "--Excel Data");

			if (keywords.toLowerCase().trim().equals(pageKeywords)) {
				// int parseInt = Integer.parseInt(INDEX);
		//		Excel_utils.writeinexcel4("PASS", parseInt);
				// Excel_utils.writeinexcel7(pageKeywords, parseInt);
				System.out.println("PASS");
			} else {

				// int parseInt = Integer.parseInt(INDEX);
	//			Excel_utils.writeinexcel4("FAIL", parseInt);
	//			Excel_utils.writeinexcel7(pageKeywords, parseInt);
				System.out.println("FAIL");

			}
		} catch (Exception e) {
			System.out.println("Keyword_Exception");
		}

		

		SimpleDateFormat dateformet = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date = new Date();
		String format = dateformet.format(date);
		// int parseInt = Integer.parseInt(INDEX);
	//	Excel_utils.writeinexcel16(format, parseInt);

		System.out.println(++count + "\t" + "is Row is completed." + "\t" + format);

	}

	@AfterTest
	public void driver_close() throws InterruptedException {

		// Thread.sleep(2000);
		driver.quit();

	}
}
