package ResponseCode;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.testng.SkipException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Get_ResponseCode extends LibGlobal {
	int count = 0;
	static int respCode = 200;
	static HttpURLConnection huc = null;

	@DataProvider
	public Iterator<Object[]> getTestData() {
		ArrayList<Object[]> testData = Excel_utils.getDataFromexcel();
		return testData.iterator();
	}

	@Parameters("browser")
	@BeforeTest
	public void browserExe() {

		launchBrowser("edge");

	}

	@Test(dataProvider = "getTestData")
	public void shouldAnswerWithTrue(String INDEX, String PageURL) throws Exception {

		loadUrl(PageURL);

		System.out.println(PageURL);

		try {

			Thread.sleep(2000);

			huc = (HttpURLConnection) (new URL(PageURL).openConnection());
			// Thread.sleep(60000);

			huc.setRequestMethod("GET");

			huc.connect();

			respCode = huc.getResponseCode();

			if (respCode != 200) {

				System.out.println(PageURL + " is a broken link" + " " + respCode);
				// int parseInt = Integer.parseInt(INDEX);
				int parseInt = Integer.parseInt(INDEX);
				Excel_utils.writeinexcel1(respCode, parseInt);

				throw new SkipException("skip");

			} else {

				System.out.println(PageURL + " is a valid link" + " " + respCode);
				// int parseInt = Integer.parseInt(INDEX);
				int parseInt = Integer.parseInt(INDEX);
				Excel_utils.writeinexcel1(respCode, parseInt);

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());

		}

		SimpleDateFormat dateformet = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date = new Date();
		String format = dateformet.format(date);
		int parseInt = Integer.parseInt(INDEX);
		Excel_utils.writeinexcel3(format, parseInt);
		System.out.println(++count + "\t" + "is Row is completed." + "\t" + format);

	}

	@AfterTest
	public void close() throws InterruptedException {

		// Thread.sleep(2000);
		driver.quit();

	}

}
