package ResponseCode;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_utils {

	public static String inputexcle;

	static Excel_Reader reader;

	public static ArrayList<Object[]> getDataFromexcel() {

		ArrayList<Object[]> myData = new ArrayList<Object[]>();
		try {

			inputexcle = "C:\\Users\\e078\\Desktop\\LIVE_URL.xlsx";

			System.out.println(inputexcle);

			reader = new Excel_Reader(inputexcle);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int rowNum = 2; rowNum <= reader.getRowCount("Sheet1"); rowNum++) {
			String INDEX = reader.getCellData("Sheet1", "INDEX", rowNum);
			String PageURL = reader.getCellData("Sheet1", "PageURL", rowNum);

			Object ob[] = { INDEX, PageURL };

			myData.add(ob);

		}
		return myData;

	}

//Int validation
	public static void writeinexcel1(int respCode, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(2);
		// int responsecode = Integer.parseInt(respCode);
		if (respCode > 200) {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(respCode);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(respCode);
		}

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// String validation
	public static void writeinexcel2(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(3);
		if (value == "FAIL") {
			XSSFCellStyle my_style = wb.createCellStyle();
			XSSFFont my_font = wb.createFont();
			my_font.setColor(XSSFFont.COLOR_RED);
			my_style.setFont(my_font);
			c.setCellValue(value);
			c.setCellStyle(my_style);

		} else {
			c.setCellValue(value);
		}
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

	// TimeStamp
	public static void writeinexcel3(String value, int INDEX) throws Exception {
		Thread.sleep(2000);
		File fis = new File(inputexcle);
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(4);

		c.setCellValue(value);

		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

}
